CREATE DATABASE payroll_db;
USE payroll_db;

CREATE TABLE payroll_raw (
    row_id INT,
    year INT,
    department_title VARCHAR(255),
    payroll_department VARCHAR(255),
    job_class_title VARCHAR(255),
    employment_type VARCHAR(100),
    projected_annual_salary VARCHAR(50),
    total_payments VARCHAR(50),
    base_pay VARCHAR(50),
    overtime_pay VARCHAR(50),
    q1_payments VARCHAR(50),
    q2_payments VARCHAR(50),
    q3_payments VARCHAR(50),
    q4_payments VARCHAR(50)
);