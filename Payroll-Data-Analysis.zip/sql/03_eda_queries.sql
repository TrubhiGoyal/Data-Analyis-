SELECT COUNT(*) FROM payroll_clean;

SELECT COUNT(DISTINCT department_title) FROM payroll_clean;

SELECT MIN(total_payments), MAX(total_payments), AVG(total_payments)
FROM payroll_clean;