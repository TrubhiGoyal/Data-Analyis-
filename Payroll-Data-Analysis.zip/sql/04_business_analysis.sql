SELECT department_title,
       SUM(total_payments) AS total_department_payroll
FROM payroll_clean
GROUP BY department_title
ORDER BY total_department_payroll DESC;

SELECT job_class_title,
       AVG(total_payments) AS avg_salary
FROM payroll_clean
GROUP BY job_class_title
ORDER BY avg_salary DESC
LIMIT 10;