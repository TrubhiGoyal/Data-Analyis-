SELECT department_title,
       job_class_title,
       total_payments,
       RANK() OVER (PARTITION BY department_title ORDER BY total_payments DESC) AS dept_rank
FROM payroll_clean;

WITH yearly_payroll AS (
    SELECT year, SUM(total_payments) AS total_yearly_payroll
    FROM payroll_clean
    GROUP BY year
)
SELECT year,
       total_yearly_payroll,
       LAG(total_yearly_payroll) OVER (ORDER BY year) AS previous_year
FROM yearly_payroll;