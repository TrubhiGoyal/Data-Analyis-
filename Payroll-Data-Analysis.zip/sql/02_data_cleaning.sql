CREATE TABLE payroll_clean AS
SELECT
    row_id,
    year,
    department_title,
    payroll_department,
    job_class_title,
    employment_type,
    CAST(REPLACE(REPLACE(projected_annual_salary,'$',''),',','') AS DECIMAL(12,2)) projected_annual_salary,
    CAST(REPLACE(REPLACE(total_payments,'$',''),',','') AS DECIMAL(12,2)) total_payments,
    CAST(REPLACE(REPLACE(base_pay,'$',''),',','') AS DECIMAL(12,2)) base_pay,
    CAST(REPLACE(REPLACE(overtime_pay,'$',''),',','') AS DECIMAL(12,2)) overtime_pay,
    CAST(REPLACE(REPLACE(q1_payments,'$',''),',','') AS DECIMAL(12,2)) q1_payments,
    CAST(REPLACE(REPLACE(q2_payments,'$',''),',','') AS DECIMAL(12,2)) q2_payments,
    CAST(REPLACE(REPLACE(q3_payments,'$',''),',','') AS DECIMAL(12,2)) q3_payments,
    CAST(REPLACE(REPLACE(q4_payments,'$',''),',','') AS DECIMAL(12,2)) q4_payments
FROM payroll_raw;