# 💼 Payroll Data Analysis Project (SQL + Excel)

## 📌 Project Overview
End-to-end payroll data analysis project using MySQL.
Includes data cleaning, EDA, business KPIs, and advanced SQL techniques.

## 🛠 Tools Used
- MySQL
- Excel
- SQL (CTE, Window Functions, Aggregations)
- GitHub

## 📂 Workflow
1. Data Import
2. Data Cleaning
3. Exploratory Data Analysis (EDA)
4. Business Analysis
5. Advanced SQL

---

## 🔍 Sample EDA Query
SELECT COUNT(*) FROM payroll_clean;

SELECT MIN(total_payments), MAX(total_payments), AVG(total_payments)
FROM payroll_clean;

---

## 🚀 Advanced SQL Example
WITH yearly_payroll AS (
    SELECT year, SUM(total_payments) AS total_yearly_payroll
    FROM payroll_clean
    GROUP BY year
)
SELECT year,
       total_yearly_payroll,
       LAG(total_yearly_payroll) OVER (ORDER BY year) AS previous_year
FROM yearly_payroll;

---

## 🎯 Skills Demonstrated
✔ Data Cleaning  
✔ Aggregations  
✔ Window Functions  
✔ CTEs  
✔ KPI Analysis  

---
Freelance-ready SQL Data Analysis Project
